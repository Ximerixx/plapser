<?php
declare(strict_types=1);

namespace OCA\PlapserCalendar\AppInfo;

use OCP\AppFramework\App;
use OCP\AppFramework\Bootstrap\IBootContext;
use OCP\AppFramework\Bootstrap\IBootstrap;
use OCP\AppFramework\Bootstrap\IRegistrationContext;

class Application extends App implements IBootstrap {
    public const APP_ID = 'plapser_calendar';

    public function __construct() {
        parent::__construct(self::APP_ID);
    }

    public function register(IRegistrationContext $context): void {
        // Register controllers
        $context->registerService(\OCA\PlapserCalendar\Controller\AdminController::class, function ($c) {
            return new \OCA\PlapserCalendar\Controller\AdminController(
                self::APP_ID,
                $c->query(\OCP\IRequest::class),
                $c->query(\OCP\IGroupManager::class),
                $c->query(\OCP\IConfig::class),
                $c->query(\OCP\ILogger::class),
                $c->query(\OCP\IL10N::class),
                new \OCA\PlapserCalendar\Db\Mapper($c->query(\OCP\IDBConnection::class)),
                new \OCA\PlapserCalendar\Service\PlapserApiService($c->query(\OCP\ILogger::class))
            );
        });

        // Register services
        $context->registerService(\OCA\PlapserCalendar\Service\UserSubgroupService::class, function ($c) {
            return new \OCA\PlapserCalendar\Service\UserSubgroupService(
                $c->query(\OCP\IDBConnection::class),
                $c->query(\OCP\IUserManager::class),
                $c->query(\OCP\ILogger::class)
            );
        });

        // Register background job
        $context->registerService(\OCA\PlapserCalendar\BackgroundJob\SyncJob::class, function ($c) {
            return new \OCA\PlapserCalendar\BackgroundJob\SyncJob(
                $c->query(\OCP\IConfig::class),
                $c->query(\OCP\IDBConnection::class),
                $c->query(\OCP\Calendar\IManager::class),
                $c->query(\OCP\IGroupManager::class)
            );
        });

        // Register admin page
        $context->registerAdmin(\OCA\PlapserCalendar\Controller\AdminController::class, 'index');
    }

    public function boot(IBootContext $context): void {
        // Boot logic if needed
        $context->injectFn(function (\OCP\IDBConnection $db, \OCP\IUserManager $userManager, \OCP\ILogger $logger) {
            // Initialize database tables
            $mapper = new \OCA\PlapserCalendar\Db\Mapper($db);
            $mapper->createTables();
            
            // Initialize user subgroup service tables
            $userSubgroupService = new \OCA\PlapserCalendar\Service\UserSubgroupService($db, $userManager, $logger);
            $userSubgroupService->createTables();
        });
    }
}
