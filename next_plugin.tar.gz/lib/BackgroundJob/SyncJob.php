<?php
declare(strict_types=1);

namespace OCA\PlapserCalendar\BackgroundJob;

use OCP\BackgroundJob\TimedJob;
use OCP\IConfig;
use OCP\IDBConnection;
use OCP\Calendar\IManager;
use OCP\IGroupManager;
use OCP\ILogger;
use OCA\PlapserCalendar\Service\PlapserApiService;
use OCA\PlapserCalendar\Service\CalendarService;
use OCA\PlapserCalendar\Db\Mapper;

class SyncJob extends TimedJob {
    private IConfig $config;
    private IDBConnection $db;
    private IManager $calendarManager;
    private IGroupManager $groupManager;
    private ILogger $logger;
    private PlapserApiService $apiService;
    private CalendarService $calendarService;
    private Mapper $mapper;

    public function __construct(
        IConfig $config,
        IDBConnection $db,
        IManager $calendarManager,
        IGroupManager $groupManager
    ) {
        parent::__construct();
        
        $this->config = $config;
        $this->db = $db;
        $this->calendarManager = $calendarManager;
        $this->groupManager = $groupManager;
        
        // Set interval to run every hour (3600 seconds)
        $this->setInterval(3600);
        
        $this->logger = \OC::$server->get(ILogger::class);
        $this->apiService = new PlapserApiService($this->logger);
        $this->calendarService = new CalendarService(
            $this->calendarManager,
            $this->groupManager,
            \OC::$server->get(\OCP\IUserManager::class),
            $this->logger
        );
        $this->mapper = new Mapper($this->db);
    }

    protected function run($argument): void {
        $this->logger->info('Starting Plapser calendar sync job');

        try {
            // Get all group mappings
            $mappings = $this->mapper->getGroupMappings();
            
            foreach ($mappings as $mapping) {
                $this->syncGroupCalendar($mapping);
            }

            $this->logger->info('Plapser calendar sync job completed');
        } catch (\Exception $e) {
            $this->logger->error('Plapser calendar sync job failed: ' . $e->getMessage());
        }
    }

    private function syncGroupCalendar(array $mapping): void {
        $nextcloudGroupId = $mapping['nextcloud_group_id'];
        $externalGroupName = $mapping['external_group_name'];
        $apiDomain = $mapping['api_domain'];
        $mappingId = $mapping['id'];

        $this->logger->info("Syncing calendar for group: {$nextcloudGroupId} -> {$externalGroupName}");

        try {
            // Get or create calendar
            $calendarName = "Расписание {$externalGroupName}";
            $calendar = $this->calendarService->getOrCreateGroupCalendar($nextcloudGroupId, $calendarName);

            if (!$calendar) {
                $this->logger->error("Failed to get/create calendar for group: {$nextcloudGroupId}");
                return;
            }

            // Fetch schedule data
            $today = new \DateTime();
            $date = $today->format('Y-m-d');
            
            $scheduleData = $this->apiService->fetchGroupSchedule(
                $apiDomain,
                $externalGroupName,
                $date,
                false
            );

            if (!$scheduleData) {
                $this->logger->warning("No schedule data received for group: {$externalGroupName}");
                return;
            }

            // Clear future events from calendar
            $this->calendarService->clearFutureEvents($calendar);

            // Process schedule data and create events
            $eventsCreated = 0;
            foreach ($scheduleData as $date => $dayData) {
                if (!isset($dayData['lessons']) || !is_array($dayData['lessons'])) {
                    continue;
                }

                foreach ($dayData['lessons'] as $lesson) {
                    if (isset($lesson['status']) && $lesson['status'] === 'Нет пар') {
                        continue; // Skip "no lessons" entries
                    }

                    if ($this->calendarService->createEventFromLesson($calendar, $lesson, $date)) {
                        $eventsCreated++;
                    }
                }
            }

            // Update last sync time
            $this->mapper->updateLastSync($mappingId, time());

            $this->logger->info("Successfully synced calendar for group: {$nextcloudGroupId}. Created {$eventsCreated} events.");

        } catch (\Exception $e) {
            $this->logger->error("Failed to sync calendar for group {$nextcloudGroupId}: " . $e->getMessage());
        }
    }
}
