<?php
declare(strict_types=1);

return [
    'routes' => [
        [
            'name' => 'admin#index',
            'url' => '/admin',
            'verb' => 'GET',
            'requirements' => [],
            'defaults' => [
                'controller' => 'AdminController',
                'action' => 'index'
            ]
        ],
        [
            'name' => 'admin#getExternalGroups',
            'url' => '/admin/get-external-groups',
            'verb' => 'POST',
            'requirements' => [],
            'defaults' => [
                'controller' => 'AdminController',
                'action' => 'getExternalGroups'
            ]
        ],
        [
            'name' => 'admin#testConnection',
            'url' => '/admin/test-connection',
            'verb' => 'POST',
            'requirements' => [],
            'defaults' => [
                'controller' => 'AdminController',
                'action' => 'testConnection'
            ]
        ],
        [
            'name' => 'admin#addMapping',
            'url' => '/admin/add-mapping',
            'verb' => 'POST',
            'requirements' => [],
            'defaults' => [
                'controller' => 'AdminController',
                'action' => 'addMapping'
            ]
        ],
        [
            'name' => 'admin#removeMapping',
            'url' => '/admin/remove-mapping',
            'verb' => 'POST',
            'requirements' => [],
            'defaults' => [
                'controller' => 'AdminController',
                'action' => 'removeMapping'
            ]
        ],
        [
            'name' => 'admin#updateDefaultApiDomain',
            'url' => '/admin/update-default-api-domain',
            'verb' => 'POST',
            'requirements' => [],
            'defaults' => [
                'controller' => 'AdminController',
                'action' => 'updateDefaultApiDomain'
            ]
        ],
        [
            'name' => 'admin#triggerSync',
            'url' => '/admin/trigger-sync',
            'verb' => 'POST',
            'requirements' => [],
            'defaults' => [
                'controller' => 'AdminController',
                'action' => 'triggerSync'
            ]
        ]
    ]
];
