<?php
declare(strict_types=1);

namespace OCA\PlapserCalendar\Service;

use GuzzleHttp\Client;
use GuzzleHttp\Exception\GuzzleException;
use OCP\ILogger;

class PlapserApiService {
    private Client $httpClient;
    private ILogger $logger;

    public function __construct(ILogger $logger) {
        $this->httpClient = new Client([
            'timeout' => 30,
            'verify' => false // For development, should be true in production
        ]);
        $this->logger = $logger;
    }

    /**
     * Fetch schedule data for a specific group and date range
     */
    public function fetchGroupSchedule(string $apiDomain, string $group, string $date, bool $tomorrow = false, ?int $subgroup = null): ?array {
        try {
            $params = [
                'group' => $group,
                'type' => 'json-week', // Get a week of data
                'date' => $date
            ];

            if ($tomorrow) {
                $params['tomorrow'] = 'true';
            }

            // Only add subgroup parameter if explicitly provided
            if ($subgroup !== null) {
                $params['subgroup'] = (string)$subgroup;
            }

            $url = rtrim($apiDomain, '/') . '/gen?' . http_build_query($params);
            
            $this->logger->info("Fetching schedule from: " . $url);

            $response = $this->httpClient->get($url);
            $data = json_decode($response->getBody()->getContents(), true);

            if (json_last_error() !== JSON_ERROR_NONE) {
                $this->logger->error("Failed to parse JSON response: " . json_last_error_msg());
                return null;
            }

            return $data;

        } catch (GuzzleException $e) {
            $this->logger->error("API request failed: " . $e->getMessage());
            return null;
        }
    }

    /**
     * Get available groups from the API
     */
    public function fetchAvailableGroups(string $apiDomain): ?array {
        try {
            $url = rtrim($apiDomain, '/') . '/api/groups';
            
            $response = $this->httpClient->get($url);
            $data = json_decode($response->getBody()->getContents(), true);

            if (json_last_error() !== JSON_ERROR_NONE) {
                $this->logger->error("Failed to parse groups JSON: " . json_last_error_msg());
                return null;
            }

            return $data;

        } catch (GuzzleException $e) {
            $this->logger->error("Failed to fetch groups: " . $e->getMessage());
            return null;
        }
    }

    /**
     * Test API connectivity
     */
    public function testConnection(string $apiDomain): bool {
        try {
            $url = rtrim($apiDomain, '/') . '/api/groups';
            $response = $this->httpClient->get($url, ['timeout' => 10]);
            return $response->getStatusCode() === 200;
        } catch (GuzzleException $e) {
            $this->logger->error("API connection test failed: " . $e->getMessage());
            return false;
        }
    }
}
