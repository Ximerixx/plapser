# Plapser Calendar Sync - Nextcloud Plugin

This Nextcloud plugin integrates with the Plapser API to automatically create and update shared calendars for Nextcloud groups based on external schedule data.

## Features

- **Lightweight Server-Side**: Minimal resource usage with efficient background processing
- **Admin Panel Integration**: Full integration with Nextcloud admin panel
- **Group Mapping**: Link Nextcloud groups to external groups from the Plapser API
- **Configurable API Domain**: Support for different API endpoints
- **Automatic Sync**: Configurable periodic updates (default: hourly)
- **Shared Calendars**: Creates calendars shared among group members
- **Event Preservation**: Does not modify past events, relies on Nextcloud storage
- **Subgroup Support**: Optional filtering by subgroups (1 or 2)

## Requirements

- Nextcloud 25+
- PHP 7.4+
- Guzzle HTTP client
- Calendar app enabled

## Installation

1. Copy the plugin to your Nextcloud apps directory:
   ```bash
   cp -r plapser_nextcloud-plugin /path/to/nextcloud/apps/plapser_calendar
   ```

2. Install dependencies:
   ```bash
   cd /path/to/nextcloud/apps/plapser_calendar
   composer install
   ```

3. Enable the app in Nextcloud admin panel or via CLI:
   ```bash
   php occ app:enable plapser_calendar
   ```

## Configuration

### Admin Panel Setup

1. Go to **Settings** → **Administration** → **Plapser Calendar Sync**
2. Configure the default API domain (default: `https://api.durka.su`)
3. Add group mappings:
   - Select a Nextcloud group
   - Choose an external group from the API
   - Optionally specify a subgroup (1 or 2)
   - Click "Add Mapping"

### API Configuration

The plugin supports the following Plapser API endpoints:
- `/gen` - Generate schedule data
- `/api/groups` - Get available groups
- `/api/teachers` - Get available teachers

Required parameters for schedule generation:
- `group` - External group name
- `type=json-week` - Return JSON format for a week
- `date` - Date in YYYY-MM-DD format
- `subgroup` (optional) - Subgroup filter (1 or 2)

## How It Works

1. **Background Sync**: The plugin runs a background job every hour (configurable)
2. **API Fetching**: For each mapped group, it fetches schedule data from the Plapser API
3. **Calendar Creation**: Creates shared calendars for groups if they don't exist
4. **Event Processing**: Parses JSON data and creates calendar events
5. **Event Management**: Clears future events and recreates them with fresh data
6. **Past Event Preservation**: Leaves historical events untouched

## Data Flow

```
Plapser API → JSON Data → Event Parser → Nextcloud Calendar → Shared Group Access
```

## API Response Format

The plugin expects JSON responses in this format:
```json
{
  "2025-01-21": {
    "date": "21 января 2025",
    "dayOfWeek": "Вторник",
    "lessons": [
      {
        "time": "09:00 - 10:30",
        "type": "лек.",
        "name": "Математика",
        "subgroup": "1",
        "classroom": "Ауд. 101",
        "teacher": "Иванов И.И."
      }
    ]
  }
}
```

## Troubleshooting

### Common Issues

1. **API Connection Failed**
   - Check if the API domain is correct
   - Verify network connectivity
   - Test the connection using the admin panel

2. **No Groups Available**
   - Ensure the API endpoint `/api/groups` is accessible
   - Check API server status

3. **Calendar Not Created**
   - Verify group has at least one member
   - Check Calendar app is enabled
   - Review Nextcloud logs for errors

4. **Events Not Appearing**
   - Check background job execution
   - Verify group mapping configuration
   - Review API response format

### Logs

Check Nextcloud logs for detailed error information:
```bash
tail -f /path/to/nextcloud/data/nextcloud.log | grep plapser
```

## Development

### Project Structure
```
plapser_nextcloud-plugin/
├── appinfo/
│   ├── info.xml
│   └── application.php
├── lib/
│   ├── AppInfo/
│   ├── BackgroundJob/
│   ├── Controller/
│   ├── Db/
│   ├── Service/
│   └── Routes.php
├── templates/
│   └── admin.php
├── composer.json
└── README.md
```

### Key Components

- **PlapserApiService**: Handles API communication
- **CalendarService**: Manages Nextcloud calendar operations
- **SyncJob**: Background job for periodic synchronization
- **AdminController**: Admin panel interface
- **Mapper**: Database operations

## License

AGPL-3.0-or-later

## Support

For issues and feature requests, please create an issue in the project repository.
