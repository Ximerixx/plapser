<?php
declare(strict_types=1);

namespace OCA\plapser_calendar\AppInfo;

// Prevent multiple class declarations
if (class_exists('OCA\plapser_calendar\AppInfo\Application')) {
    return;
}

// Let Nextcloud's autoloader handle the class loading

use OCP\AppFramework\App;
use OCP\AppFramework\Bootstrap\IBootContext;
use OCP\AppFramework\Bootstrap\IBootstrap;
use OCP\AppFramework\Bootstrap\IRegistrationContext;

class Application extends App implements IBootstrap {
    public const APP_ID = 'plapser_calendar';

    public function __construct() {
        parent::__construct(self::APP_ID);
    }

    public function register(IRegistrationContext $context): void {
        // Register controllers
        $context->registerService(\OCA\plapser_calendar\Controller\AdminController::class, function ($c) {
            return new \OCA\plapser_calendar\Controller\AdminController(
                self::APP_ID,
                $c->query(\OCP\IRequest::class),
                $c->query(\OCP\IGroupManager::class),
                $c->query(\OCP\IConfig::class),
                $c->query(\OCP\ILogger::class),
                $c->query(\OCP\IL10N::class),
                new \OCA\plapser_calendar\Db\Mapper($c->query(\OCP\IDBConnection::class)),
                new \OCA\plapser_calendar\Service\PlapserApiService($c->query(\OCP\ILogger::class))
            );
        });

        // Register services
        $context->registerService(\OCA\plapser_calendar\Service\UserSubgroupService::class, function ($c) {
            return new \OCA\plapser_calendar\Service\UserSubgroupService(
                $c->query(\OCP\IDBConnection::class),
                $c->query(\OCP\IUserManager::class),
                $c->query(\OCP\ILogger::class)
            );
        });

        // Register background job
        $context->registerService(\OCA\plapser_calendar\BackgroundJob\SyncJob::class, function ($c) {
            return new \OCA\plapser_calendar\BackgroundJob\SyncJob(
                $c->query(\OCP\AppFramework\Utility\ITimeFactory::class),
                $c->query(\OCP\IConfig::class),
                $c->query(\OCP\IDBConnection::class),
                $c->query(\OCP\Calendar\IManager::class),
                $c->query(\OCP\IGroupManager::class)
            );
        });

        // Admin page is registered via info.xml <admin> tag
    }

    public function boot(IBootContext $context): void {
        // Boot logic - tables will be created when needed
    }
}
