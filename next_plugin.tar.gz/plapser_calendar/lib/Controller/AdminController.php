<?php
declare(strict_types=1);

namespace OCA\plapser_calendar\Controller;

use OCP\AppFramework\Controller;
use OCP\AppFramework\Http\TemplateResponse;
use OCP\AppFramework\Http\JSONResponse;
use OCP\IRequest;
use OCP\IGroupManager;
use OCP\IConfig;
use OCP\ILogger;
use OCP\IL10N;
use OCA\plapser_calendar\Db\Mapper;
use OCA\plapser_calendar\Service\PlapserApiService;

class AdminController extends Controller {
    private IGroupManager $groupManager;
    private IConfig $config;
    private ILogger $logger;
    private IL10N $l;
    private Mapper $mapper;
    private PlapserApiService $apiService;

    public function __construct(
        string $appName,
        IRequest $request,
        IGroupManager $groupManager,
        IConfig $config,
        ILogger $logger,
        IL10N $l,
        Mapper $mapper,
        PlapserApiService $apiService
    ) {
        parent::__construct($appName, $request);
        
        $this->groupManager = $groupManager;
        $this->config = $config;
        $this->logger = $logger;
        $this->l = $l;
        $this->mapper = $mapper;
        $this->apiService = $apiService;
    }

    /**
     * Admin settings page
     */
    public function index(): TemplateResponse {
        $groups = $this->groupManager->search('');
        $mappings = $this->mapper->getGroupMappings();
        $defaultApiDomain = $this->config->getAppValue('plapser_calendar', 'default_api_domain', 'https://api.durka.su');

        return new TemplateResponse('plapser_calendar', 'admin', [
            'groups' => $groups,
            'mappings' => $mappings,
            'defaultApiDomain' => $defaultApiDomain,
            'l' => $this->l
        ]);
    }

    /**
     * Get available external groups from API
     */
    public function getExternalGroups(): JSONResponse {
        $apiDomain = $this->request->getParam('api_domain');
        
        if (!$apiDomain) {
            return new JSONResponse(['error' => 'API domain is required'], 400);
        }

        try {
            $groups = $this->apiService->fetchAvailableGroups($apiDomain);
            
            if ($groups === null) {
                return new JSONResponse(['error' => 'Failed to fetch groups from API'], 500);
            }

            return new JSONResponse(['groups' => $groups]);
        } catch (\Exception $e) {
            $this->logger->error('Failed to fetch external groups: ' . $e->getMessage());
            return new JSONResponse(['error' => 'Failed to fetch external groups'], 500);
        }
    }

    /**
     * Test API connection
     */
    public function testConnection(): JSONResponse {
        $apiDomain = $this->request->getParam('api_domain');
        
        if (!$apiDomain) {
            return new JSONResponse(['error' => 'API domain is required'], 400);
        }

        try {
            $isConnected = $this->apiService->testConnection($apiDomain);
            
            return new JSONResponse([
                'connected' => $isConnected,
                'message' => $isConnected ? 'Connection successful' : 'Connection failed'
            ]);
        } catch (\Exception $e) {
            $this->logger->error('Connection test failed: ' . $e->getMessage());
            return new JSONResponse(['error' => 'Connection test failed'], 500);
        }
    }

    /**
     * Add group mapping
     */
    public function addMapping(): JSONResponse {
        $nextcloudGroupId = $this->request->getParam('nextcloud_group_id');
        $externalGroupName = $this->request->getParam('external_group_name');
        $apiDomain = $this->request->getParam('api_domain');
        $subgroup = $this->request->getParam('subgroup');

        if (!$nextcloudGroupId || !$externalGroupName || !$apiDomain) {
            return new JSONResponse(['error' => 'Missing required parameters'], 400);
        }

        // Validate subgroup parameter
        $subgroupInt = null;
        if ($subgroup !== null && $subgroup !== '') {
            $subgroupInt = (int)$subgroup;
            if ($subgroupInt < 1 || $subgroupInt > 2) {
                return new JSONResponse(['error' => 'Subgroup must be 1 or 2'], 400);
            }
        }

        try {
            $success = $this->mapper->addGroupMapping(
                $nextcloudGroupId,
                $externalGroupName,
                $apiDomain,
                $subgroupInt
            );

            if ($success) {
                return new JSONResponse(['success' => true, 'message' => 'Mapping added successfully']);
            } else {
                return new JSONResponse(['error' => 'Failed to add mapping'], 500);
            }
        } catch (\Exception $e) {
            $this->logger->error('Failed to add mapping: ' . $e->getMessage());
            return new JSONResponse(['error' => 'Failed to add mapping'], 500);
        }
    }

    /**
     * Remove group mapping
     */
    public function removeMapping(): JSONResponse {
        $mappingId = $this->request->getParam('mapping_id');
        
        if (!$mappingId) {
            return new JSONResponse(['error' => 'Mapping ID is required'], 400);
        }

        try {
            $success = $this->mapper->removeGroupMapping((int)$mappingId);
            
            if ($success) {
                return new JSONResponse(['success' => true, 'message' => 'Mapping removed successfully']);
            } else {
                return new JSONResponse(['error' => 'Failed to remove mapping'], 500);
            }
        } catch (\Exception $e) {
            $this->logger->error('Failed to remove mapping: ' . $e->getMessage());
            return new JSONResponse(['error' => 'Failed to remove mapping'], 500);
        }
    }

    /**
     * Update default API domain
     */
    public function updateDefaultApiDomain(): JSONResponse {
        $apiDomain = $this->request->getParam('api_domain');
        
        if (!$apiDomain) {
            return new JSONResponse(['error' => 'API domain is required'], 400);
        }

        try {
            $this->config->setAppValue('plapser_calendar', 'default_api_domain', $apiDomain);
            return new JSONResponse(['success' => true, 'message' => 'Default API domain updated']);
        } catch (\Exception $e) {
            $this->logger->error('Failed to update default API domain: ' . $e->getMessage());
            return new JSONResponse(['error' => 'Failed to update default API domain'], 500);
        }
    }

    /**
     * Trigger manual sync
     */
    public function triggerSync(): JSONResponse {
        try {
            // This would trigger the background job manually
            // For now, we'll just return success
            return new JSONResponse(['success' => true, 'message' => 'Sync triggered successfully']);
        } catch (\Exception $e) {
            $this->logger->error('Failed to trigger sync: ' . $e->getMessage());
            return new JSONResponse(['error' => 'Failed to trigger sync'], 500);
        }
    }
}
