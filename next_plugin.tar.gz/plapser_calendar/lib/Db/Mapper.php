<?php
declare(strict_types=1);

namespace OCA\PlapserCalendar\Db;

use OCP\IDBConnection;
use OCP\DB\QueryBuilder\IQueryBuilder;

class Mapper {
    private IDBConnection $db;

    public function __construct(IDBConnection $db) {
        $this->db = $db;
        $this->ensureTablesExist();
    }

    /**
     * Ensure tables exist (call createTables if needed)
     */
    private function ensureTablesExist(): void {
        $this->createTables();
    }

    /**
     * Create database tables
     */
    public function createTables(): void {
        $sql = '
            CREATE TABLE IF NOT EXISTS `*PREFIX*plapser_group_mappings` (
                `id` INTEGER PRIMARY KEY AUTOINCREMENT,
                `nextcloud_group_id` VARCHAR(255) NOT NULL,
                `external_group_name` VARCHAR(255) NOT NULL,
                `api_domain` VARCHAR(255) NOT NULL,
                `subgroup` INTEGER DEFAULT NULL,
                `last_sync` INTEGER DEFAULT 0,
                `created_at` INTEGER DEFAULT 0,
                UNIQUE(`nextcloud_group_id`, `external_group_name`)
            )
        ';
        $this->db->executeQuery($sql);

        $sql = '
            CREATE TABLE IF NOT EXISTS `*PREFIX*plapser_calendar_settings` (
                `id` INTEGER PRIMARY KEY AUTOINCREMENT,
                `setting_key` VARCHAR(255) NOT NULL UNIQUE,
                `setting_value` TEXT NOT NULL,
                `updated_at` INTEGER DEFAULT 0
            )
        ';
        $this->db->executeQuery($sql);
    }

    /**
     * Get all group mappings
     */
    public function getGroupMappings(): array {
        $qb = $this->db->getQueryBuilder();
        $qb->select('*')
           ->from('plapser_group_mappings')
           ->orderBy('created_at', 'DESC');

        return $qb->executeQuery()->fetchAll();
    }

    /**
     * Add a new group mapping
     */
    public function addGroupMapping(string $nextcloudGroupId, string $externalGroupName, string $apiDomain, ?int $subgroup = null): bool {
        try {
            $qb = $this->db->getQueryBuilder();
            $qb->insert('plapser_group_mappings')
               ->values([
                   'nextcloud_group_id' => $qb->createNamedParameter($nextcloudGroupId),
                   'external_group_name' => $qb->createNamedParameter($externalGroupName),
                   'api_domain' => $qb->createNamedParameter($apiDomain),
                   'subgroup' => $qb->createNamedParameter($subgroup, IQueryBuilder::PARAM_INT),
                   'created_at' => $qb->createNamedParameter(time())
               ]);

            $qb->executeStatement();
            return true;
        } catch (\Exception $e) {
            return false;
        }
    }

    /**
     * Remove a group mapping
     */
    public function removeGroupMapping(int $mappingId): bool {
        try {
            $qb = $this->db->getQueryBuilder();
            $qb->delete('plapser_group_mappings')
               ->where($qb->expr()->eq('id', $qb->createNamedParameter($mappingId, IQueryBuilder::PARAM_INT)));

            $qb->executeStatement();
            return true;
        } catch (\Exception $e) {
            return false;
        }
    }

    /**
     * Update last sync time for a mapping
     */
    public function updateLastSync(int $mappingId, int $timestamp): void {
        $qb = $this->db->getQueryBuilder();
        $qb->update('plapser_group_mappings')
           ->set('last_sync', $qb->createNamedParameter($timestamp))
           ->where($qb->expr()->eq('id', $qb->createNamedParameter($mappingId, IQueryBuilder::PARAM_INT)));

        $qb->executeStatement();
    }

    /**
     * Get setting value
     */
    public function getSetting(string $key): ?string {
        $qb = $this->db->getQueryBuilder();
        $qb->select('setting_value')
           ->from('plapser_calendar_settings')
           ->where($qb->expr()->eq('setting_key', $qb->createNamedParameter($key)));

        $result = $qb->executeQuery()->fetchOne();
        return $result ?: null;
    }

    /**
     * Set setting value
     */
    public function setSetting(string $key, string $value): void {
        $qb = $this->db->getQueryBuilder();
        // Check if setting exists
        $existing = $this->getSetting($key);
        if ($existing !== null) {
            $qb = $this->db->getQueryBuilder();
            $qb->update('plapser_calendar_settings')
               ->set('setting_value', $qb->createNamedParameter($value))
               ->set('updated_at', $qb->createNamedParameter(time()))
               ->where($qb->expr()->eq('setting_key', $qb->createNamedParameter($key)));
        } else {
            $qb = $this->db->getQueryBuilder();
            $qb->insert('plapser_calendar_settings')
               ->values([
                   'setting_key' => $qb->createNamedParameter($key),
                   'setting_value' => $qb->createNamedParameter($value),
                   'updated_at' => $qb->createNamedParameter(time())
               ]);
        }

        $qb->executeStatement();
    }
}
