<?php
declare(strict_types=1);

namespace OCA\plapser_calendar\Service;

use OCP\Calendar\IManager;
use OCP\Calendar\ICalendar;
use OCP\Calendar\ICreateFromString;
use OCP\Calendar\IEvent;
use OCP\Calendar\IManager as CalendarManager;
use OCP\IGroupManager;
use OCP\IUserManager;
use OCP\ILogger;

class CalendarService {
    private IManager $calendarManager;
    private IGroupManager $groupManager;
    private IUserManager $userManager;
    private ILogger $logger;

    public function __construct(
        IManager $calendarManager,
        IGroupManager $groupManager,
        IUserManager $userManager,
        ILogger $logger
    ) {
        $this->calendarManager = $calendarManager;
        $this->groupManager = $groupManager;
        $this->userManager = $userManager;
        $this->logger = $logger;
    }

    /**
     * Create or get calendar for a group
     */
    public function getOrCreateGroupCalendar(string $groupId, string $calendarName): ?ICalendar {
        $group = $this->groupManager->get($groupId);
        if (!$group) {
            $this->logger->error("Group not found: " . $groupId);
            return null;
        }

        // Try to find existing calendar
        $calendars = $this->calendarManager->getCalendars([], true);
        foreach ($calendars as $calendar) {
            if ($calendar->getDisplayName() === $calendarName) {
                return $calendar;
            }
        }

        // Create new calendar - we'll need to get a user from the group to create it
        $users = $group->getUsers();
        if (empty($users)) {
            $this->logger->error("No users in group: " . $groupId);
            return null;
        }

        $firstUser = $users[0];
        $calendarUri = 'plapser_' . $groupId . '_' . time();

        // Create calendar using the first user in the group
        $calendar = $this->calendarManager->createCalendar(
            $firstUser->getUID(),
            $calendarUri,
            $calendarName,
            'Plapser schedule calendar for group ' . $groupId,
            '#ff6600', // Orange color
            true, // enabled
            1, // order
            false // supports events
        );

        if ($calendar) {
            // Share the calendar with all group members
            $this->shareCalendarWithGroup($calendar, $group);
            $this->logger->info("Created calendar: " . $calendarName . " for group: " . $groupId);
        }

        return $calendar;
    }

    /**
     * Share calendar with all group members
     */
    private function shareCalendarWithGroup(ICalendar $calendar, $group): void {
        // Note: This is a simplified implementation
        // In a real implementation, you'd need to use the Sharing API
        // For now, we'll assume the calendar is accessible to group members
        // through the group's permissions
    }

    /**
     * Clear all events from a calendar (except past events)
     */
    public function clearFutureEvents(ICalendar $calendar): void {
        $searchStart = new \DateTime();
        $searchEnd = new \DateTime('+1 year');

        $events = $calendar->search('', [], [], $searchStart, $searchEnd);

        foreach ($events as $event) {
            $eventStart = $event->getStartDate();
            if ($eventStart >= $searchStart) {
                $calendar->deleteEvent($event->getKey());
            }
        }
    }

    /**
     * Create event from lesson data using Nextcloud native API
     */
    public function createEventFromLesson(ICalendar $calendar, array $lesson, string $date): bool {
        try {
            // Parse time range (e.g., "09:00 - 10:30")
            if (!isset($lesson['time']) || !strpos($lesson['time'], '-')) {
                return false;
            }

            [$startTime, $endTime] = explode('-', $lesson['time']);
            $startTime = trim($startTime);
            $endTime = trim($endTime);

            // Parse date components
            [$year, $month, $day] = explode('-', $date);

            // Create start and end datetime
            $startDateTime = new \DateTime();
            $startDateTime->setDate((int)$year, (int)$month, (int)$day);
            [$startHour, $startMin] = explode(':', $startTime);
            $startDateTime->setTime((int)$startHour, (int)$startMin);

            $endDateTime = new \DateTime();
            $endDateTime->setDate((int)$year, (int)$month, (int)$day);
            [$endHour, $endMin] = explode(':', $endTime);
            $endDateTime->setTime((int)$endHour, (int)$endMin);

            // Create event summary
            $summary = $lesson['name'] ?? 'Занятие';
            if (isset($lesson['type']) && $lesson['type']) {
                $summary .= ' (' . $lesson['type'] . ')';
            }

            // Create detailed description with all available information
            $description = '';
            if (isset($lesson['teacher']) && $lesson['teacher']) {
                $description .= "Преподаватель: " . $lesson['teacher'] . "\n";
            }
            if (isset($lesson['subgroup']) && $lesson['subgroup']) {
                $description .= "Подгруппа: " . $lesson['subgroup'] . "\n";
            }
            if (isset($lesson['groups']) && is_array($lesson['groups'])) {
                $description .= "Группы: " . implode(', ', $lesson['groups']) . "\n";
            }
            if (isset($lesson['classroom']) && $lesson['classroom']) {
                $description .= "Аудитория: " . $lesson['classroom'] . "\n";
            }

            // Create location
            $location = $lesson['classroom'] ?? '';

            // Generate unique UID for the event
            $uid = 'plapser_' . md5($date . $lesson['time'] . $summary) . '@plapser.local';

            // Use ICS format for creating events (Nextcloud standard approach)
            $icsContent = $this->generateICSContent(
                $summary,
                $description,
                $location,
                $startDateTime,
                $endDateTime,
                $uid
            );

            // Create event in calendar
            if ($calendar instanceof ICreateFromString) {
                $calendar->createFromString($icsContent);
                return true;
            }

            return false;

        } catch (\Exception $e) {
            $this->logger->error("Failed to create event: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Generate ICS content for an event
     */
    private function generateICSContent(string $summary, string $description, string $location, \DateTime $start, \DateTime $end, string $uid = null): string {
        if ($uid === null) {
            $uid = uniqid('plapser_') . '@plapser.local';
        }
        
        return "BEGIN:VCALENDAR\r\n" .
               "VERSION:2.0\r\n" .
               "PRODID:-//Plapser Calendar//EN\r\n" .
               "BEGIN:VEVENT\r\n" .
               "UID:" . $uid . "\r\n" .
               "DTSTART:" . $start->format('Ymd\THis\Z') . "\r\n" .
               "DTEND:" . $end->format('Ymd\THis\Z') . "\r\n" .
               "SUMMARY:" . $this->escapeICS($summary) . "\r\n" .
               "DESCRIPTION:" . $this->escapeICS($description) . "\r\n" .
               "LOCATION:" . $this->escapeICS($location) . "\r\n" .
               "END:VEVENT\r\n" .
               "END:VCALENDAR\r\n";
    }

    /**
     * Escape text for ICS format
     */
    private function escapeICS(string $text): string {
        return str_replace(["\r\n", "\n", "\r", ',', ';'], ['\\n', '\\n', '\\n', '\\,', '\\;'], $text);
    }
}
