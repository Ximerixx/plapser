<?php
declare(strict_types=1);

namespace OCA\plapser_calendar\Service;

use OCP\IDBConnection;
use OCP\IUserManager;
use OCP\ILogger;

class UserSubgroupService {
    private IDBConnection $db;
    private IUserManager $userManager;
    private ?ILogger $logger;

    public function __construct(
        IDBConnection $db,
        IUserManager $userManager,
        ?ILogger $logger = null
    ) {
        $this->db = $db;
        $this->userManager = $userManager;
        $this->logger = $logger;
        $this->ensureTablesExist();
    }

    /**
     * Ensure tables exist (call createTables if needed)
     */
    private function ensureTablesExist(): void {
        $this->createTables();
    }

    /**
     * Create user subgroup assignments table
     */
    public function createTables(): void {
        $sql = '
            CREATE TABLE IF NOT EXISTS `*PREFIX*plapser_user_subgroups` (
                `id` INTEGER PRIMARY KEY AUTOINCREMENT,
                `user_id` VARCHAR(255) NOT NULL,
                `group_id` VARCHAR(255) NOT NULL,
                `subgroup` INTEGER DEFAULT NULL,
                `created_at` INTEGER DEFAULT 0,
                UNIQUE(`user_id`, `group_id`)
            )
        ';
        $this->db->executeQuery($sql);
    }

    /**
     * Assign user to a specific subgroup within a group
     */
    public function assignUserToSubgroup(string $userId, string $groupId, ?int $subgroup = null): bool {
        try {
            $qb = $this->db->getQueryBuilder();
            $qb->insert('plapser_user_subgroups')
               ->values([
                   'user_id' => $qb->createNamedParameter($userId),
                   'group_id' => $qb->createNamedParameter($groupId),
                   'subgroup' => $qb->createNamedParameter($subgroup),
                   'created_at' => $qb->createNamedParameter(time())
               ]);

            $qb->executeStatement();
            return true;
        } catch (\Exception $e) {
            if ($this->logger) {
                $this->logger->error("Failed to assign user to subgroup: " . $e->getMessage());
            }
            return false;
        }
    }

    /**
     * Get user's subgroup assignment for a specific group
     */
    public function getUserSubgroup(string $userId, string $groupId): ?int {
        $qb = $this->db->getQueryBuilder();
        $qb->select('subgroup')
           ->from('plapser_user_subgroups')
           ->where($qb->expr()->eq('user_id', $qb->createNamedParameter($userId)))
           ->andWhere($qb->expr()->eq('group_id', $qb->createNamedParameter($groupId)));

        $result = $qb->executeQuery()->fetchOne();
        return $result !== false ? (int)$result : null;
    }

    /**
     * Get all users and their subgroup assignments for a group
     */
    public function getGroupSubgroupAssignments(string $groupId): array {
        $qb = $this->db->getQueryBuilder();
        $qb->select('user_id', 'subgroup')
           ->from('plapser_user_subgroups')
           ->where($qb->expr()->eq('group_id', $qb->createNamedParameter($groupId)));

        $results = $qb->executeQuery()->fetchAll();
        $assignments = [];

        foreach ($results as $row) {
            $assignments[$row['user_id']] = $row['subgroup'] ? (int)$row['subgroup'] : null;
        }

        return $assignments;
    }

    /**
     * Update user's subgroup assignment
     */
    public function updateUserSubgroup(string $userId, string $groupId, ?int $subgroup): bool {
        try {
            $qb = $this->db->getQueryBuilder();
            $qb->update('plapser_user_subgroups')
               ->set('subgroup', $qb->createNamedParameter($subgroup))
               ->where($qb->expr()->eq('user_id', $qb->createNamedParameter($userId)))
               ->andWhere($qb->expr()->eq('group_id', $qb->createNamedParameter($groupId)));

            $qb->executeStatement();
            return true;
        } catch (\Exception $e) {
            if ($this->logger) {
                $this->logger->error("Failed to update user subgroup: " . $e->getMessage());
            }
            return false;
        }
    }

    /**
     * Remove user's subgroup assignment
     */
    public function removeUserSubgroup(string $userId, string $groupId): bool {
        try {
            $qb = $this->db->getQueryBuilder();
            $qb->delete('plapser_user_subgroups')
               ->where($qb->expr()->eq('user_id', $qb->createNamedParameter($userId)))
               ->andWhere($qb->expr()->eq('group_id', $qb->createNamedParameter($groupId)));

            $qb->executeStatement();
            return true;
        } catch (\Exception $e) {
            if ($this->logger) {
                $this->logger->error("Failed to remove user subgroup: " . $e->getMessage());
            }
            return false;
        }
    }

    /**
     * Check if lesson is relevant for user based on their subgroup assignment
     */
    public function isLessonRelevantForUser(array $lesson, string $userId, string $groupId): bool {
        $userSubgroup = $this->getUserSubgroup($userId, $groupId);
        
        // If user has no subgroup assignment, show all lessons
        if ($userSubgroup === null) {
            return true;
        }

        // If lesson has no subgroup specified, it's for all subgroups
        if (!isset($lesson['subgroup']) || empty($lesson['subgroup'])) {
            return true;
        }

        // Check if user's subgroup matches lesson's subgroup
        return $userSubgroup === (int)$lesson['subgroup'];
    }
}
