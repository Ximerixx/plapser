<?php
/** @var array $groups */
/** @var array $mappings */
/** @var string $defaultApiDomain */
/** @var \OCP\IL10N $l */
?>

<div class="section" id="plapser-calendar-admin">
    <h2>Синхронизация календаря Plapser</h2>
    
    <div class="plapser-admin-container">
        <!-- Default API Domain Configuration -->
        <div class="plapser-config-section">
            <h3>Конфигурация API по умолчанию</h3>
            <div class="plapser-config-row">
                <label for="default-api-domain">Домен API по умолчанию:</label>
                <input type="text" id="default-api-domain" value="<?php p($defaultApiDomain); ?>" 
                       placeholder="https://api.durka.su" class="plapser-input">
                <button id="update-default-api" class="plapser-button">Обновить</button>
            </div>
        </div>

        <!-- Group Mappings -->
        <div class="plapser-config-section">
            <h3>Сопоставления групп</h3>
            
            <!-- Add New Mapping -->
            <div class="plapser-add-mapping">
                <h4>Добавить новое сопоставление групп</h4>
                <div class="plapser-form-row">
                    <label for="api-domain">Домен API:</label>
                    <input type="text" id="api-domain" value="<?php p($defaultApiDomain); ?>" 
                           placeholder="https://api.durka.su" class="plapser-input">
                    <button id="test-connection" class="plapser-button secondary">Проверить соединение</button>
                </div>
                
                <div class="plapser-form-row">
                    <label for="nextcloud-group">Группа Nextcloud:</label>
                    <select id="nextcloud-group" class="plapser-select">
                        <option value="">Выберите группу...</option>
                        <?php foreach ($groups as $group): ?>
                            <option value="<?php p($group->getGID()); ?>">
                                <?php p($group->getDisplayName()); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="plapser-form-row">
                    <label for="external-group">Внешняя группа:</label>
                    <select id="external-group" class="plapser-select" disabled>
                        <option value="">Сначала выберите домен API...</option>
                    </select>
                    <button id="refresh-groups" class="plapser-button secondary" disabled>Обновить группы</button>
                </div>
                
                <div class="plapser-form-row">
                    <button id="add-mapping" class="plapser-button primary" disabled>Добавить сопоставление</button>
                </div>
            </div>
            
            <!-- Existing Mappings -->
            <div class="plapser-existing-mappings">
                <h4>Существующие сопоставления</h4>
                <div id="mappings-list">
                    <?php if (empty($mappings)): ?>
                        <p class="plapser-no-mappings">Пока не настроено ни одного сопоставления групп.</p>
                    <?php else: ?>
                        <?php foreach ($mappings as $mapping): ?>
                            <div class="plapser-mapping-item" data-mapping-id="<?php p($mapping['id']); ?>">
                                <div class="plapser-mapping-info">
                                    <strong><?php p($mapping['nextcloud_group_id']); ?></strong> 
                                    → 
                                    <em><?php p($mapping['external_group_name']); ?></em>
                                </div>
                                <div class="plapser-mapping-details">
                                    <span class="plapser-api-domain"><?php p($mapping['api_domain']); ?></span>
                                    <span class="plapser-last-sync">
                                        Последняя синхронизация: <?php p(date('d.m.Y H:i:s', $mapping['last_sync'])); ?>
                                    </span>
                                </div>
                                <button class="plapser-remove-mapping plapser-button danger" 
                                        data-mapping-id="<?php p($mapping['id']); ?>">Удалить</button>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Manual Sync -->
        <div class="plapser-config-section">
            <h3>Ручные операции</h3>
            <div class="plapser-form-row">
                <button id="trigger-sync" class="plapser-button primary">Запустить синхронизацию</button>
                <span class="plapser-help-text">Вручную запустить синхронизацию для всех настроенных групп</span>
            </div>
        </div>
    </div>
</div>

<style>
.plapser-admin-container {
    max-width: 800px;
}

.plapser-config-section {
    margin-bottom: 2rem;
    padding: 1rem;
    border: 1px solid #ddd;
    border-radius: 4px;
    background: #f9f9f9;
}

.plapser-config-row,
.plapser-form-row {
    margin-bottom: 1rem;
    display: flex;
    align-items: center;
    gap: 0.5rem;
}

.plapser-config-row label,
.plapser-form-row label {
    min-width: 150px;
    font-weight: bold;
}

.plapser-input,
.plapser-select {
    flex: 1;
    padding: 0.5rem;
    border: 1px solid #ccc;
    border-radius: 3px;
}

.plapser-button {
    padding: 0.5rem 1rem;
    border: none;
    border-radius: 3px;
    cursor: pointer;
    font-size: 0.9rem;
}

.plapser-button.primary {
    background: #0082c9;
    color: white;
}

.plapser-button.secondary {
    background: #6c757d;
    color: white;
}

.plapser-button.danger {
    background: #dc3545;
    color: white;
}

.plapser-button:disabled {
    background: #ccc;
    cursor: not-allowed;
}

.plapser-add-mapping {
    margin-bottom: 2rem;
    padding: 1rem;
    border: 1px solid #ddd;
    border-radius: 4px;
    background: white;
}

.plapser-mapping-item {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 0.75rem;
    margin-bottom: 0.5rem;
    border: 1px solid #ddd;
    border-radius: 4px;
    background: white;
}

.plapser-mapping-info {
    flex: 1;
}

.plapser-mapping-details {
    flex: 1;
    font-size: 0.9rem;
    color: #666;
}

.plapser-subgroup {
    color: #666;
    font-style: italic;
}

.plapser-api-domain {
    display: block;
    font-family: monospace;
}

.plapser-last-sync {
    display: block;
    font-size: 0.8rem;
}

.plapser-no-mappings {
    color: #666;
    font-style: italic;
    text-align: center;
    padding: 2rem;
}

.plapser-help-text {
    color: #666;
    font-size: 0.9rem;
}

.plapser-status {
    margin-left: 1rem;
    padding: 0.25rem 0.5rem;
    border-radius: 3px;
    font-size: 0.8rem;
}

.plapser-status.success {
    background: #d4edda;
    color: #155724;
}

.plapser-status.error {
    background: #f8d7da;
    color: #721c24;
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const apiDomainInput = document.getElementById('api-domain');
    const externalGroupSelect = document.getElementById('external-group');
    const refreshGroupsBtn = document.getElementById('refresh-groups');
    const testConnectionBtn = document.getElementById('test-connection');
    const addMappingBtn = document.getElementById('add-mapping');
    const defaultApiInput = document.getElementById('default-api-domain');
    const updateDefaultApiBtn = document.getElementById('update-default-api');
    const triggerSyncBtn = document.getElementById('trigger-sync');

    // Test API connection
    testConnectionBtn.addEventListener('click', function() {
        const apiDomain = apiDomainInput.value.trim();
        if (!apiDomain) {
            showStatus('Пожалуйста, введите домен API', 'error');
            return;
        }

        testConnectionBtn.disabled = true;
        testConnectionBtn.textContent = 'Проверка...';

        fetch('/apps/plapser_calendar/admin/test-connection', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ api_domain: apiDomain })
        })
        .then(response => response.json())
        .then(data => {
            if (data.connected) {
                showStatus('Соединение успешно!', 'success');
                refreshGroupsBtn.disabled = false;
            } else {
                showStatus('Соединение не удалось: ' + (data.message || 'Неизвестная ошибка'), 'error');
            }
        })
        .catch(error => {
            showStatus('Ошибка проверки соединения: ' + error.message, 'error');
        })
        .finally(() => {
            testConnectionBtn.disabled = false;
            testConnectionBtn.textContent = 'Проверить соединение';
        });
    });

    // Refresh external groups
    refreshGroupsBtn.addEventListener('click', function() {
        const apiDomain = apiDomainInput.value.trim();
        if (!apiDomain) {
            showStatus('Please enter an API domain', 'error');
            return;
        }

        refreshGroupsBtn.disabled = true;
        refreshGroupsBtn.textContent = 'Загрузка...';

        fetch('/apps/plapser_calendar/admin/get-external-groups', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ api_domain: apiDomain })
        })
        .then(response => response.json())
        .then(data => {
            if (data.groups) {
                externalGroupSelect.innerHTML = '<option value="">Select a group...</option>';
                data.groups.forEach(group => {
                    const option = document.createElement('option');
                    option.value = group;
                    option.textContent = group;
                    externalGroupSelect.appendChild(option);
                });
                externalGroupSelect.disabled = false;
                addMappingBtn.disabled = false;
                showStatus('Groups loaded successfully', 'success');
            } else {
                showStatus('Failed to load groups: ' + (data.error || 'Unknown error'), 'error');
            }
        })
        .catch(error => {
            showStatus('Failed to load groups: ' + error.message, 'error');
        })
        .finally(() => {
            refreshGroupsBtn.disabled = false;
            refreshGroupsBtn.textContent = 'Обновить группы';
        });
    });

    // Add mapping
    addMappingBtn.addEventListener('click', function() {
        const nextcloudGroup = document.getElementById('nextcloud-group').value;
        const externalGroup = externalGroupSelect.value;
        const apiDomain = apiDomainInput.value.trim();
        const subgroup = document.getElementById('subgroup').value;

        if (!nextcloudGroup || !externalGroup || !apiDomain) {
            showStatus('Please fill in all required fields', 'error');
            return;
        }

        addMappingBtn.disabled = true;
        addMappingBtn.textContent = 'Adding...';

        fetch('/apps/plapser_calendar/admin/add-mapping', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                nextcloud_group_id: nextcloudGroup,
                external_group_name: externalGroup,
                api_domain: apiDomain,
                subgroup: subgroup || null
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                showStatus('Mapping added successfully', 'success');
                location.reload(); // Refresh page to show new mapping
            } else {
                showStatus('Failed to add mapping: ' + (data.error || 'Unknown error'), 'error');
            }
        })
        .catch(error => {
            showStatus('Failed to add mapping: ' + error.message, 'error');
        })
        .finally(() => {
            addMappingBtn.disabled = false;
            addMappingBtn.textContent = 'Add Mapping';
        });
    });

    // Remove mapping
    document.addEventListener('click', function(e) {
        if (e.target.classList.contains('plapser-remove-mapping')) {
            const mappingId = e.target.dataset.mappingId;
            if (confirm('Are you sure you want to remove this mapping?')) {
                fetch('/apps/plapser_calendar/admin/remove-mapping', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({ mapping_id: mappingId })
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        showStatus('Mapping removed successfully', 'success');
                        e.target.closest('.plapser-mapping-item').remove();
                    } else {
                        showStatus('Failed to remove mapping: ' + (data.error || 'Unknown error'), 'error');
                    }
                })
                .catch(error => {
                    showStatus('Failed to remove mapping: ' + error.message, 'error');
                });
            }
        }
    });

    // Update default API domain
    updateDefaultApiBtn.addEventListener('click', function() {
        const apiDomain = defaultApiInput.value.trim();
        if (!apiDomain) {
            showStatus('Please enter an API domain', 'error');
            return;
        }

        updateDefaultApiBtn.disabled = true;
        updateDefaultApiBtn.textContent = 'Updating...';

        fetch('/apps/plapser_calendar/admin/update-default-api-domain', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ api_domain: apiDomain })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                showStatus('Default API domain updated successfully', 'success');
            } else {
                showStatus('Failed to update API domain: ' + (data.error || 'Unknown error'), 'error');
            }
        })
        .catch(error => {
            showStatus('Failed to update API domain: ' + error.message, 'error');
        })
        .finally(() => {
            updateDefaultApiBtn.disabled = false;
            updateDefaultApiBtn.textContent = 'Update';
        });
    });

    // Trigger manual sync
    triggerSyncBtn.addEventListener('click', function() {
        triggerSyncBtn.disabled = true;
        triggerSyncBtn.textContent = 'Syncing...';

        fetch('/apps/plapser_calendar/admin/trigger-sync', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            }
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                showStatus('Manual sync triggered successfully', 'success');
            } else {
                showStatus('Failed to trigger sync: ' + (data.error || 'Unknown error'), 'error');
            }
        })
        .catch(error => {
            showStatus('Failed to trigger sync: ' + error.message, 'error');
        })
        .finally(() => {
            triggerSyncBtn.disabled = false;
            triggerSyncBtn.textContent = 'Trigger Manual Sync';
        });
    });

    function showStatus(message, type) {
        // Remove existing status messages
        document.querySelectorAll('.plapser-status').forEach(status => status.remove());
        
        const status = document.createElement('span');
        status.className = 'plapser-status ' + type;
        status.textContent = message;
        
        // Add status to the first form row
        const firstRow = document.querySelector('.plapser-form-row');
        if (firstRow) {
            firstRow.appendChild(status);
        }
        
        // Auto-remove after 5 seconds
        setTimeout(() => {
            status.remove();
        }, 5000);
    }
});
</script>
